﻿Shader "Unlit/matViS"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        _Azimuth("Azimuth", Float) = 0
        _Polar("Polar", Float) = 0
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            // make fog work
            #pragma multi_compile_fog

            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float2 uv : TEXCOORD0;
                UNITY_FOG_COORDS(1)
                float4 vertex : SV_POSITION;
            };

            sampler2D _MainTex;
            float4 _MainTex_ST;
            uniform float _Azimuth;
            uniform float _Polar;

            v2f vert (appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                //return tex2D(_MainTex, float2(i.uv.x + _Azimuth, i.uv.y - _Polar));
               return tex2D(_MainTex, float2(i.uv.x + _Azimuth, i.uv.y + _Polar));
            }
            ENDCG
        }
    }
}
