﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class ViS : MonoBehaviour
{
    public Material mat;

    public float vis;
    public GameObject Foreg;
    public GameObject g1;
    public GameObject g2; 
    public GameObject g3;
    public GameObject g4;
    public GameObject g5;
    public GameObject g6;
    public GameObject g7;
    public GameObject g8;
    public GameObject g9;
    public GameObject g10;
    public GameObject g11;
    public float diff_azimuth;
    public float diff_polar;

    string[] list_location;
    int reference_user_idx;
    string vis_mtx_list;
    string[] vis_mtx_str;
    int idx;
    string[] pose;
    int user_idx;
    float ti;
    float reference_time;
    int reference_idx;
    string[] reference_pose;
    float reference_polar;
    float reference_azimuth;
    int time_difference;
    int M = 11;
    List<GameObject> goList;
    int resWidth = 1080;
    int resHeight = 1080;
    Texture2D snapshot;
    byte[] bytes;
    float novel_polar;
    float novel_azimuth;
    GameObject g;
    List<float> visList;
    int visIndex;
    float dis;
    int layerIndex;
    int lo;
    int hi;
    int mid;
    GameObject[] gs;

    // Start is called before the first frame update
    void Start()
    {

        //QualitySettings.vSyncCount = 0;
        //Application.targetFrameRate = 120;
        goList = new List<GameObject>();
        visList = new List<float>();
        snapshot = new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);
        string[] objectNames = new string[] { "Particle", "prop" };
        foreach (string objectName in objectNames)
        {
            GameObject go = GameObject.Find(objectName);
            Transform[] allChildren = go.GetComponentsInChildren<Transform>(true);
            foreach (Transform child in allChildren)
            {
                if ((child.childCount == 0) && (child.gameObject.activeInHierarchy))
                {
                    goList.Add(child.gameObject);
                }
            }
        }
        g = GameObject.Find("g");
        gs = new GameObject[] {g, g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11 };
        list_location = ReadStream(Application.persistentDataPath + "/pose.txt");
        reference_user_idx = -1;
        vis_mtx_list = File.ReadAllText(Application.persistentDataPath + "/visValue.txt");
        vis_mtx_str = vis_mtx_list.Split(',');
        idx = 0;
        Foreg.gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (idx <= 10000)
        {
            idx = idx + 1;

            pose = list_location[idx].Split(',');
            user_idx = int.Parse(pose[0].Trim('['));
            ti = float.Parse(pose[1]);
            if (user_idx != reference_user_idx)
            {
                reference_user_idx = user_idx;
                reference_time = ti;
                reference_idx = idx;

                reference_pose = list_location[reference_idx].Split(',');
                reference_polar = float.Parse(reference_pose[8]);
                reference_azimuth = float.Parse(reference_pose[9].Trim(']'));
                foreach (GameObject gobj in gs)
                {
                    gobj.gameObject.SetActive(true);
                    gobj.transform.position = new Vector3(float.Parse(reference_pose[2]), float.Parse(reference_pose[3]), float.Parse(reference_pose[4]));
                    gobj.transform.eulerAngles = new Vector3(float.Parse(reference_pose[5]), float.Parse(reference_pose[6]), float.Parse(reference_pose[7]));
                }
                Foreg.gameObject.SetActive(false);
                vis = 50.0f;
                if (visList.Count > 0)
                {
                    CheckLayer();
                }

            }
            else
            {
                time_difference = Mathf.FloorToInt((ti - reference_time) * 60.0f);
                if (time_difference >= M)
                {
                    reference_user_idx = user_idx;
                    reference_time = ti;
                    reference_idx = idx;

                    reference_pose = list_location[reference_idx].Split(',');
                    reference_polar = float.Parse(reference_pose[8]);
                    reference_azimuth = float.Parse(reference_pose[9].Trim(']'));

                    foreach (GameObject gobj in gs)
                    {
                        gobj.gameObject.SetActive(true);
                        gobj.transform.position = new Vector3(float.Parse(reference_pose[2]), float.Parse(reference_pose[3]), float.Parse(reference_pose[4]));
                        gobj.transform.eulerAngles = new Vector3(float.Parse(reference_pose[5]), float.Parse(reference_pose[6]), float.Parse(reference_pose[7]));
                    }

                    Foreg.gameObject.SetActive(false);
                    vis = 50.0f;
                    
                    if (visList.Count > 0)
                    {
                        CheckLayer();
                    }

                }

                else
                {
                    Foreg.gameObject.SetActive(true);
                    Foreg.transform.position = new Vector3(float.Parse(pose[2]), float.Parse(pose[3]), float.Parse(pose[4]));
                    Foreg.transform.eulerAngles = new Vector3(float.Parse(pose[5]), float.Parse(pose[6]), float.Parse(pose[7]));
                    novel_polar = float.Parse(pose[8]);
                    novel_azimuth = float.Parse(pose[9].Trim(']'));
                    diff_azimuth = (novel_azimuth - reference_azimuth) / 90.0f;
                    diff_polar = (novel_polar - reference_polar) / 90.0f;

                    /*
                    foreach (Camera camera in cameras)
                    {
                        camera.SetReplacementShader(EffectShader, "RenderType");
                    }

                    ForeCam.SetReplacementShader(EffectShader, "RenderType");
                    */
                    vis = float.Parse(vis_mtx_str[time_difference]);

                    if (!visList.Contains(vis))
                    {
                        visList.Add(vis);
                    }
                    else 
                    {
                        visIndex = visList.IndexOf(vis);

                        gs[gs.Length - visIndex - 1].gameObject.SetActive(false);

                        CheckFore();
                    }
                }
            }
            }

    }

    void OnRenderImage(UnityEngine.RenderTexture src, UnityEngine.RenderTexture dest) 
    {
        if (vis < 50.0)
        {
            mat.SetFloat("_Azimuth", diff_azimuth);
            mat.SetFloat("_Polar", diff_polar);
        }
        else
        {
            mat.SetFloat("_Azimuth", 0);
            mat.SetFloat("_Polar", 0);
        }
        Graphics.Blit(src, dest, mat);
    }

    public string[] ReadStream(String path)
    {
        string[] list = File.ReadAllLines(path);
        return list;
    }

    void CheckLayer()
    {
        foreach (GameObject go in goList)
        {
            dis = Vector3.Distance(go.transform.position, g.transform.position);
            layerIndex = search(dis, visList) + 8;
            go.layer = layerIndex;
        }
    }

    void CheckFore()
    {
        layerIndex = visList.IndexOf(vis) + 8;
        foreach (GameObject go in goList)
        {
            if (go.layer <= layerIndex+1)
            {
                go.layer = 20;
            }
        }
    }

    public int search(float value, List<float> a)
    {
        if (value < a[0])
        {
            return 0;
        }
        if (value > a[a.Count-1])
        {
            return a.Count;
        }

        lo = 0;
        hi = a.Count-1;

        while (lo <= hi)
        {
            mid = (hi + lo) / 2;

            if (value < a[mid])
            {
                hi = mid - 1;
            }
            else if (value > a[mid])
            {
                lo = mid + 1;
            }
            else
            {
                return mid;
            }
        }
        return (a[lo] - value) > 0? lo : hi;
    }

}
