﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UVPostProcessing : MonoBehaviour
{
    public Material mat;
    ViS dynamicSplitting;
    float vis;
    float diff_azimuth;
    float diff_polar;
    void Start()
    {
        dynamicSplitting = GameObject.FindObjectOfType<ViS>();
        
    }
    
    void OnRenderImage(UnityEngine.RenderTexture src, UnityEngine.RenderTexture dest)
    {
        diff_azimuth = dynamicSplitting.diff_azimuth;
        diff_polar = dynamicSplitting.diff_polar;
        vis= dynamicSplitting.vis;
        mat.SetFloat("_Azimuth", diff_azimuth);
        mat.SetFloat("_Polar", diff_polar);
        if (vis < 45.0)
        {
            mat.SetFloat("_Azimuth", diff_azimuth);
            mat.SetFloat("_Polar", diff_polar);
        }
        else
        {
            mat.SetFloat("_Azimuth", 0);
            mat.SetFloat("_Polar", 0);
        }
        Graphics.Blit(src, dest, mat);
    }
    
}
