function hy= calculate_hypergeom(j,m_j,para)
global h
if h(j,m_j)==0
    h(j,m_j)=hypergeom(j,m_j,para);
end
hy=h(j,m_j);


