clear all;
close all;
clc;
%%%%%%%%%%%%%%%%%%%Parameters for Orientation Model(VikingVillage, Delta t=60/60s, Headset VR)%%%%%%%%%%%%%%%%%%%%%%%%%%
polar_b=3.401771159631409;
azimuth_b=11.401037490756957;
%%%%%%%%%%%%%%%%%%FoV term%%%%%%%%%%%%%%%%%%%%%%%%%%%
azimuth_b=azimuth_b/180*pi;
polar_b=polar_b/180*pi;
fv=pi/2;
analysis_temp=1-(polar_b - (polar_b + fv)/exp(fv/(polar_b)))/fv;
analysis_fov=analysis_temp*(1-(azimuth_b - (azimuth_b + fv)/exp(fv/(azimuth_b)))/fv);

%%%%%%%%%%%%%%%%%%%Parameters for Position Model(VikingVillage, Delta t=60/60s, Headset VR)%%%%%%%%%%%%%%%%%%%%%%%%%%
mu=1/1.7541858558558583;
lambda=1/0.3160794294294291;
co=0.46546546546546547;
t=6/6;
global h;
h=zeros(3,100);
for k=1:30
    m(k)=calculate_m_k(mu,lambda,co,t,k); %k-th moment of the position displacement
end

varepsilon=0.7;

%%%%%%%%%%%%%%%%%%Distance term%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=30;
d=2:1:50;
g=0;
for i=0:N-1
    gg(i+1)=(-1)^i*varepsilon^(-(2*i+1))*m(i+1)/factorial(i)/(i+0.5);
    g=g+gg(i+1);
end
analysis_distance=1+m(1)./d.^2-4*sin(fv/2)/fv./d/sqrt(pi)*g;

analysis=analysis_distance*analysis_fov;
hold on;
plot(d,analysis);
ylim([0,1]);