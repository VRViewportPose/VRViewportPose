function sum= calculate_m_k(mu,lambda,co,t,k)

NN=2;
v=1.5;

sum=0;

for m=1:NN

    C=nchoosek(m+k-1,m-1);
    moment1=factorial(2.*k)./factorial(2.*k+m-1).*(1-co).^(m-1).*mu.^(m-1).*lambda./(lambda+mu).*t.^(2.*k+m-1).*exp(-mu.*t);
    if m>1
        
        for j=1:m-1
            moment1=moment1+lambda./(lambda+mu).*mu.^(m-1).*(lambda.*co).^j.*(1-co).^(m-1-j)*nchoosek(m-1,j).*t.^(2.*k+m+j-1).*exp(-mu.*t).*factorial(2*k)./factorial(2.*k+m+j-1).*calculate_hypergeom(j,2.*k+m+j,-(lambda.*co-mu)*t);
        end
    end
    
    
    moment2=0;
    for j=1:m
        moment2=moment2+lambda./(lambda+mu).*mu.^m.*(lambda.*co).^(j-1).*(1-co).^(m-j).*nchoosek(m-1,j-1).*t.^(2.*k+m-1+j).*exp(-mu.*t).*factorial(2*k)./factorial(2.*k+m-1+j).*calculate_hypergeom(j,2.*k+m+j,-(lambda.*co-mu)*t);
    end
    
    moment3=0;
    
    for j=1:m
        moment3=moment3+mu./(lambda+mu).*mu.^(m-1).*lambda.^j.*co.^(j-1).*(1-co).^(m-j).*nchoosek(m-1,j-1).*t.^(2.*k+m-1+j).*exp(-mu.*t).*factorial(2*k)./factorial(2.*k+m-1+j).*calculate_hypergeom(j,2.*k+m+j,-(lambda.*co-mu)*t);
    end
    
    moment4=0;
    for j=2
        moment4=moment4+mu./(lambda+mu).*mu.^m.*lambda.^(j-1)*co.^(j-2).*(1-co).^(m-j+1).*nchoosek(m-1,j-2).*t.^(2.*k+m+j-1).*exp(-mu.*t).*factorial(2*k)./factorial(2.*k+m+j-1).*calculate_hypergeom(j,2.*k+m+j,-(lambda.*co-mu)*t);
    end
    moment=moment1+moment2+moment3+moment4;
    sum=sum+C*moment;
end

sum=sum*v^(2*k);
