﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class IRBCamera : MonoBehaviour
{
    Camera camera;
    string[] list_location;

    int location_num = 500;
    int location_idx;
    byte[] depthData;
    Texture2D depthTexture;
    byte[] textureData;
    Texture2D RGBTexture;
    string[] pose;
    int temp_loc;
    int iIter;
    int jIter;
    int resol = 1080;
    float depth;
    float x;
    float xx;
    float yy;
    Vector3[,] WorldPoint;
    float[,] newDepth;
    Texture2D newTexture;
    Vector3[,] ScreenPoint;
    int newX;
    int newY;
    float newXX;
    float newYY;
    float polarscle;
    float azimuthscale;
    Color c;
    byte[] novelCamera;
    // Start is called before the first frame update
    void Start()
    {
        camera = GetComponent<Camera>();
        ScreenPoint = new Vector3[resol, resol];
        depthTexture = new Texture2D(resol, resol);
        RGBTexture = new Texture2D(resol, resol);
        WorldPoint = new Vector3[resol, resol];

        list_location = ReadStream("Assets/NovelReferencePair.txt");

        for (int loc = 2; loc <= location_num; loc = loc+2)
        {
            location_idx = loc;
            // Read the pixels from the depth map

            depthData = File.ReadAllBytes("Assets/depth/Litedepth" + location_idx + ".png");
            depthTexture.LoadImage(depthData);
            //Read the pixels from the texture map
            temp_loc = location_idx - 2;
            textureData = File.ReadAllBytes("Assets/texture/Litetexture" + temp_loc + ".png");

            RGBTexture.LoadImage(textureData);

            pose = list_location[location_idx - 2].Split(',');
            camera.transform.position = new Vector3(float.Parse(pose[2]), float.Parse(pose[3]), float.Parse(pose[4]));
            camera.transform.eulerAngles = new Vector3(float.Parse(pose[5]), float.Parse(pose[6]), float.Parse(pose[7]));
            Debug.Log("success");
            StartCoroutine("ViewportProjection");
        }
    }


    IEnumerator ViewportProjection()
    {
        //Convert the pixels reference camera to the world space
        newDepth = new float[resol, resol];
        newTexture = new Texture2D(resol, resol);
        for (iIter = 0; iIter < resol; iIter++)
        {
            for (jIter = 0; jIter < resol; jIter++)
            {
                depth = depthTexture.GetPixel(iIter, jIter).r;
                depth = depth * camera.farClipPlane;
                x = Mathf.Tan((iIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI);
                xx = resol / 2 + Mathf.Tan((iIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI) * resol / 2;
                yy = resol / 2 + Mathf.Tan((jIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI) * Mathf.Sqrt(1 + x * x) * resol / 2;
                WorldPoint[iIter, jIter] = camera.ScreenToWorldPoint(new Vector3(xx, yy, depth));

            }
        }

        pose = list_location[location_idx-1].Split(',');
        camera.transform.position = new Vector3(float.Parse(pose[2]), float.Parse(pose[3]), float.Parse(pose[4]));
        camera.transform.eulerAngles = new Vector3(float.Parse(pose[5]), float.Parse(pose[6]), float.Parse(pose[7]));


        //Convert the points in the world space to the novel camera
        for (iIter = 0; iIter < resol; iIter++)
        {
                for (jIter = 0; jIter < resol; jIter++)
                {

                        ScreenPoint[iIter, jIter] = camera.WorldToScreenPoint(WorldPoint[iIter, jIter]);

                        newXX = ScreenPoint[iIter, jIter].x;
                        newYY = ScreenPoint[iIter, jIter].y;
                        polarscle = 180 / Mathf.PI * Mathf.Asin(2 * (newYY - resol / 2) / resol / Mathf.Sqrt(1 + 4 * (newXX - resol / 2) * (newXX - resol / 2) / resol / resol + 4 * (newYY - resol / 2) * (newYY - resol / 2) / resol / resol)) / 45;
                        azimuthscale = 180 / Mathf.PI * Mathf.Atan(2 * (newXX - resol / 2) / resol) / 45;
                        newX = Mathf.RoundToInt(resol / 2 * azimuthscale + resol / 2);
                        newY = Mathf.RoundToInt(resol / 2 * polarscle + resol / 2);
                        if ((newX < resol) && (newY < resol) && (newX >= 0) && (newY >= 0))
                        {
                            if ((newDepth[newX, newY] == 0) || (ScreenPoint[iIter, jIter].z < newDepth[newX, newY]))
                            {
                                //Debug.Log(ScreenPoint[iIter, jIter].x);
                                //Debug.Log(ScreenPoint[iIter, jIter].y);
                                c = RGBTexture.GetPixel(iIter, jIter);
                                newTexture.SetPixel(newX, newY, c);
                                newDepth[newX, newY] = ScreenPoint[iIter, jIter].z;
                            }

                        }

                }

        }
        novelCamera = newTexture.EncodeToPNG();
        temp_loc = location_idx - 1;
        File.WriteAllBytes("Assets/IRB/LitenovelCamera" + temp_loc + ".png", novelCamera);
        yield return null;
    }

    public string[] ReadStream(String path)
    {
        string[] list = File.ReadAllLines(path);
        return list;
    }
}
