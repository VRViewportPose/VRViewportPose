﻿using System;
using System.IO;
using UnityEngine;

[ExecuteInEditMode]
public class DepthCamera : MonoBehaviour
{
    [Range(0f, 3f)]
    System.Random random = new System.Random();
    public float depthLevel = 0.5f;
    int resol = 1080 * 2;
    int idx = 0;
    string[] pose;
    string[] list_location;
    float x;
    float xx;
    float yy;
    int newX;
    int newY;
    Color c;
    Texture2D depthTexture;
    Texture2D equidepth;
    byte[] textureData;
    byte[] bytes;
    int iIter;
    int jIter;
    private Shader _shader;
    private Shader shader
    {
        get { return _shader != null ? _shader : (_shader = Shader.Find("Custom/RenderDepth")); }
    }

    private Material _material;
    private Material material
    {
        get
        {
            if (_material == null)
            {
                _material = new Material(shader);
                _material.hideFlags = HideFlags.HideAndDontSave;
            }
            return _material;
        }
    }

    private void Start()
    {
        equidepth = new Texture2D(1080, 1080, TextureFormat.RGB24, false);
        depthTexture = new Texture2D(resol, resol);
        if (!SystemInfo.supportsImageEffects)
        {
            print("System doesn't support image effects");
            enabled = false;
            return;
        }
        if (shader == null || !shader.isSupported)
        {
            enabled = false;
            print("Shader " + shader.name + " is not supported");
            return;
        }
        GetComponent<Camera>().depthTextureMode = DepthTextureMode.Depth;
        list_location = ReadStream("Assets/NovelReferencePair.txt");
        
    }

    // Next update in second
    private int nextUpdate = 1;

    // Update is called once per frame
    private void Update()
    {
        if ((Time.time >= nextUpdate) && (idx < 10))
        {
            nextUpdate = Mathf.FloorToInt(Time.time) + 1;
            UpdateEverySecond();
        }

    }

    // Update is called once per second
    void UpdateEverySecond()
    {
        pose = list_location[idx].Split(',');

        transform.position = new Vector3(float.Parse(pose[2]), float.Parse(pose[3]), float.Parse(pose[4]));
        transform.eulerAngles=new Vector3(float.Parse(pose[5]), float.Parse(pose[6]), float.Parse(pose[7]));
        idx = idx + 2;
    }

    private void OnDisable()
    {
        if (_material != null)
            DestroyImmediate(_material);
    }

    private void OnRenderImage(UnityEngine.RenderTexture src, UnityEngine.RenderTexture dest)
    {
        if (shader != null)
        {
            material.SetFloat("_DepthLevel", depthLevel);
            Graphics.Blit(src, dest, material);
        }
        else
        {
            Graphics.Blit(src, dest);
        }
        System.Random rand = new System.Random();

        ScreenCapture.CaptureScreenshot("depth_temp.png");
        textureData = File.ReadAllBytes("depth_temp.png");
        depthTexture.LoadImage(textureData);

        
        for (iIter = 0; iIter < 1080; iIter++)
        {
            for (jIter = 0; jIter < 1080; jIter++)
            {
                x = Mathf.Tan((iIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI);
                xx = resol / 2 + Mathf.Tan((iIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI) * resol / 2 / Mathf.Tan(65f / 180 * Mathf.PI);
                yy = resol / 2 + Mathf.Tan((jIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI) * Mathf.Sqrt(1 + x * x) * resol / 2 / Mathf.Tan(65f / 180 * Mathf.PI);

                newX = Mathf.RoundToInt(xx);
                newY = Mathf.RoundToInt(yy);
                c = depthTexture.GetPixel(newX, newY);

                equidepth.SetPixel(iIter, jIter, c);
            }
        }
        bytes = equidepth.EncodeToPNG();
        System.IO.File.WriteAllBytes("Assets/depth" + "/" + "Litedepth" + idx + ".png", bytes);
    }

    public string[] ReadStream(String path)
    {
        string[] list = File.ReadAllLines(path);
        return list;
    }

}