﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class TextureCamera : MonoBehaviour
{
    Camera snapCam;
    private Shader _shader;
    int fieldofview = 130;
    int resWidth = 1080 * 2;
    int resHeight = 1080 * 2;
    Texture2D snapshot;
    Texture2D equiTexture;
    int idx;
    string[] list_location;

    int location_num = 500;
    string[] pose;
    int iIter;
    int jIter;
    float x;
    float xx;
    float yy;
    int newX;
    int newY;
    Color c;
    byte[] bytes;
    void Start()
    {
        snapCam = GetComponent<Camera>();
        snapCam.fieldOfView = fieldofview;
        snapshot = new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);
        equiTexture = new Texture2D(1080, 1080, TextureFormat.RGB24, false);

        list_location = ReadStream("Assets/NovelReferencePair.txt");
        TakeSnapshot();
    }

    // Update is called once per frame
    void TakeSnapshot()
    {
        if (snapCam.targetTexture == null)
        {
            snapCam.targetTexture = new UnityEngine.RenderTexture(resWidth, resHeight, 24);
        }
        else
        {
            resWidth = snapCam.targetTexture.width;
            resHeight = snapCam.targetTexture.height;
        }


        for (idx = 0; idx <= location_num; idx++)
        {
            pose = list_location[idx].Split(',');
            snapCam.transform.position = new Vector3(float.Parse(pose[2]), float.Parse(pose[3]), float.Parse(pose[4]));
            transform.eulerAngles = new Vector3(float.Parse(pose[5]), float.Parse(pose[6]), float.Parse(pose[7]));
            SaveTexture(idx);
        }
    }

    void SaveTexture(int idx)
    {
        snapCam.Render();
        UnityEngine.RenderTexture.active = snapCam.targetTexture;
        snapshot.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);

        for (iIter = 0; iIter < 1080; iIter++)
        {
            for (jIter = 0; jIter < 1080; jIter++)
            {
                x = Mathf.Tan((iIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI);
                xx = resHeight / 2 + x * resHeight / 2 / Mathf.Tan(65f / 180 * Mathf.PI);
                yy = resHeight / 2 + Mathf.Tan((jIter / 1080f - 0.5f) * 90 / 180 * Mathf.PI) * Mathf.Sqrt(1 + x * x) * resHeight / 2 / Mathf.Tan(65f / 180 * Mathf.PI);

                newX = Mathf.RoundToInt(xx);
                newY = Mathf.RoundToInt(yy);
                c = snapshot.GetPixel(newX, newY);
                equiTexture.SetPixel(iIter, jIter, c);
            }
        }

        bytes = equiTexture.EncodeToPNG();

        System.IO.File.WriteAllBytes("Assets/texture/Litetexture" + idx + ".png", bytes);
        snapCam.gameObject.SetActive(false);
    }

    public string[] ReadStream(String path)
    {
        string[] list = File.ReadAllLines(path);
        return list;
    }

}
